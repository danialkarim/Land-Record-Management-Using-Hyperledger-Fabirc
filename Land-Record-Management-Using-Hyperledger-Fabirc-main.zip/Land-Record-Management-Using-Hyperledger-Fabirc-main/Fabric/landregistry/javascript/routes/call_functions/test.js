console.log("asfasdf"+"asdfsdf");
const path = require('path');
const ccpPath = path.resolve(__dirname);
console.log(ccpPath);
